# Respectify TypeScript Client

[![npm version](https://badge.fury.io/js/respectify.svg)](https://badge.fury.io/js/respectify)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A TypeScript client library for the [Respectify API](https://respectify.ai), providing comment moderation, spam detection, toxicity analysis, and dogwhistle detection.

Respectify aims to be more than comment moderation: it tries to teach and edify users when a comment is rejected.

For bloggers, companies with articles, etc it provides a way to keep discourse civil and on-topic without censorship.

## Installation

```bash
npm install respectify
```

Requires Node.js 18 or later.

## Quick Start

```typescript
import { RespectifyClient } from "respectify";

const client = new RespectifyClient({
  email: "your-email@example.com",
  apiKey: "your-api-key",
});

// Initialize a topic — comments are evaluated in the context of an article/post
const topic = await client.initTopicFromText("This is my article content...");
const articleId = topic.article_id;

// Evaluate comment quality and toxicity
const score = await client.evaluateComment("This is a thoughtful comment", articleId);
console.log(`Comment health: ${score.overall_score}/5, Toxicity: ${score.toxicity_score.toFixed(2)}`);

// Check if a comment is spam
const spam = await client.checkSpam("Great post!", articleId);
if (spam.is_spam) {
  // Spam: delete or trash the comment
} else if (spam.suspected_spam) {
  // Suspected spam: send it back to the commenter with spam.suggestion,
  // e.g. "This looks like spam. How about removing the link?"
}

// Perspective-compatible scoring for migrations from Google's Perspective API
const perspective = await client.perspective.analyzeComment({
  comment: { text: "You clearly did not read the article." },
  requestedAttributes: {
    TOXICITY: {},
    INSULT: {},
  },
});
console.log(perspective.attributeScores.TOXICITY.summaryScore.value);
```

### Megacall for Efficiency

Perform multiple analyses in a single API call:

```typescript
const result = await client.megacall({
  comment: "Test comment",
  articleId, // from initTopicFromText() or initTopicFromUrl()
  includeSpam: true,
  includeRelevance: true,
  includeCommentScore: true,
  includeDogwhistle: true,
  bannedTopics: ["politics"],
});

console.log(`Spam: ${result.spam_check?.is_spam}`);
console.log(`Comment health: ${result.comment_score?.overall_score}/5`);
console.log(`On topic: ${result.relevance_check?.on_topic.on_topic}`);
console.log(`Dogwhistles: ${result.dogwhistle_check?.detection.dogwhistles_detected}`);
```

### Comment Health and Tolerances

Comment health has ten items: the nine problem categories and `quality`. Each call can set a tolerance level per item with `tolerances`; items not named are `standard`. Nothing is stored per API key.

```typescript
const score = await client.evaluateComment(
  "That's a dumb take, honestly",
  articleId,
  undefined, // replyToComment
  { insult: "relaxed", profanity: "off", threat: "zero_tolerance", quality: "strict" },
);

if (score.exceeds_tolerance) {
  // Some item scored below what this call's tolerances accept: coach the comment
}
console.log(score.health_score); // 1.0-5.0, absent when every item is off
console.log(score.health_items?.quality); // { score, minimum, is_acceptable }
console.log(score.tolerances); // the full set it was judged under
```

Megacall takes the same option: `client.megacall({ ..., includeCommentScore: true, tolerances: { profanity: "relaxed" } })`.

- Items (`HEALTH_ITEMS`): the categories (`MODERATION_CATEGORIES`: `threat`, `identity_attack`, `sexual_content`, `harassment`, `insult`, `profanity`, `dismissive_tone`, `logical_fallacy`, `low_effort`) and `quality` (`QUALITY_HEALTH_ITEM`)
- Levels (`TOLERANCE_LEVELS`), loosest to strictest: `off`, `permissive`, `relaxed`, `standard` (default), `strict`, `zero_tolerance`. `permissive` filters only the very worst: it accepts minor, clear and severe findings and fails only extreme ones
- Floored categories (`FLOORED_MODERATION_CATEGORIES`: `threat`, `identity_attack`, `sexual_content`, `harassment`) can be made stricter but never `permissive`, `relaxed` or `off`. The `ModerationTolerances` type rejects this at compile time, and the client throws `BadRequestError` before sending (the API would also reject it with HTTP 400). `validateModerationTolerances()` runs the same check on its own, for example on tolerances loaded from config.

Each item not turned off gets a score from 1 to 5. A problem category scores 5 when nothing is found; otherwise its worst finding sets it: minor (severity 1) 4, clear (2) 3, severe (3) 2, extreme (4) 1. A low-effort comment counts as a clear low_effort finding (3). Quality scores on the 1-5 quality rubric. The level sets the lowest score accepted (`minimum`):

| Level | Problem category | Quality |
|---|---|---|
| `permissive` | 2 (fails extreme only) | 2 |
| `relaxed` | 3 (fails severe and extreme) | 2 |
| `standard` | 4 (fails clear, severe and extreme) | 3 |
| `strict` | 5 (accepts no findings) | 4 |
| `zero_tolerance` | 5 (accepts no findings; any hint gets a full assessment) | 5 |
| `off` | not scored, not coached | not scored |

Floored categories have a minimum of 5 at every level they allow. Findings an item accepts are removed from the finding lists.

The response adds:
- `health_items` — per item not turned off: `{ score, minimum, is_acceptable }`
- `health_score` — 1.0-5.0, the geometric mean of the quality score and the worst problem item's score, leaving out whichever is off; omitted when every item is off
- `overall_score` — comment health: `health_score` rounded half up. The quality score alone is `health_items.quality.score`
- `exceeds_tolerance` — true when any item is not acceptable, or the comment is severely toxic. This is the verdict to act on

`health_items` and `health_score` are optional in the types, since older servers omit them. Each objectionable and negative-tone phrase carries a `category` and a `severity` (`FINDING_SEVERITIES`: 1 minor, 2 clear, 3 severe, 4 extreme); each logical fallacy carries a `severity`. `isFindingSeverity()` checks a value is one of these. Severe is a slur or dehumanising language, a threat, sexual harassment, urging self-harm or sustained abuse; extreme is the same at full force, such as a slur combined with a call for violence, a credible threat against a named person, or graphic sexual abuse.

### Free Plan and Revision Tokens

A free-plan account gets 200 comments for life. Revising a comment does not use up another one, as long as the client tells the API that a resubmission is a revision. The first assessment of a comment on the free plan returns a revision token in the `X-Respectify-Revision-Token` response header; send it back when the commenter resubmits that comment and the revision is free. A comment gets five attempts in all (the original and four revisions). Paid accounts never receive a token, and sending none is always allowed.

The plain methods return the bare result; their `*WithMeta` siblings return `{ result, revisionToken }` and take an options object, including `revisionToken`:

```typescript
import { FreeAllowanceExhaustedError, RevisionLimitReachedError, RateLimitedError } from "@respectify/client";

// First submission
const first = await client.megacallWithMeta({ comment, articleId, includeSpam: true, includeCommentScore: true });
if (first.result.comment_score?.exceeds_tolerance) {
  // Send the feedback back to the commenter, and keep first.revisionToken with the form
}

// The commenter revises and resubmits: pass the token back
const revised = await client.megacallWithMeta({
  comment: revisedComment,
  articleId,
  includeSpam: true,
  includeCommentScore: true,
  revisionToken: first.revisionToken,
});
```

`evaluateCommentWithMeta`, `checkSpamWithMeta`, `checkRelevanceWithMeta`, `checkDogwhistleWithMeta` and `megacallWithMeta` all work this way; `megacall` also accepts `revisionToken` in its options (it sends the token, but only `megacallWithMeta` returns the one that comes back). The Perspective-compatible endpoints never use revision tokens.

When the free plan runs out, every comment-assessing call throws `FreeAllowanceExhaustedError` (a `PaymentRequiredError`, HTTP 402) whose `upgradeUrl` is where the account owner adds credit. This is a message for the site owner, not the commenter: let the comment through unmoderated and alert the owner. A sixth attempt at a comment throws `RevisionLimitReachedError` (HTTP 409): hold the comment for a human to review. A free key over its per-minute cap throws `RateLimitedError` (HTTP 429) with `retryAfterSeconds` from the `Retry-After` header and `errorCode` `free_rate_limited`.

`checkUserCredentials()` reports a free-plan account with `status` `"free_plan"` (`active: true`, `plan_name` like "Free plan: 37 of 200 comments used") or `"free_plan_exhausted"` (`active: false`).

## API Reference

### Client Options

```typescript
const client = new RespectifyClient({
  email: "your-email@example.com", // Required
  apiKey: "your-api-key",          // Required
  baseUrl: "https://...",          // Optional, defaults to production
  version: "0.2",                  // Optional, defaults to "0.2"
  timeout: 30000,                  // Optional, milliseconds, defaults to 30000
  website: "myblog.com",           // Optional, for license tracking
});
```

### Methods

**Topic Management:**
- `initTopicFromText(text, topicDescription?)` — Initialize a topic from text content
- `initTopicFromUrl(url, topicDescription?)` — Initialize a topic from a URL

**Comment Analysis:**
- `evaluateComment(comment, articleId, replyToComment?, tolerances?)` — Comment health, quality and toxicity scoring, judged under the call's tolerances
- `checkSpam(comment, articleId?)` — Spam detection (articleId optional). Three outcomes: `is_spam` true (delete it); `suspected_spam` true (not spam, but send it back to the commenter with `suggestion`, like a comment needing revision); or neither (publish it). `suspected_spam` and `suggestion` are optional in the types, since older servers omit them: treat absent as `false` and `""`. In `megacall`, a suspected comment is not spam, so the other checks still run and are returned
- `checkRelevance(comment, articleId, bannedTopics?)` — Relevance and banned topic detection
- `checkDogwhistle(comment, articleId, sensitiveTopics?, dogwhistleExamples?)` — Dogwhistle detection

**Batch Operations:**
- `megacall(options)` — Multiple analyses in a single API call. `options.revisionToken` marks a revised resubmission

**With response metadata** (see [Free Plan and Revision Tokens](#free-plan-and-revision-tokens)):
- `evaluateCommentWithMeta(options)`, `checkSpamWithMeta(options)`, `checkRelevanceWithMeta(options)`, `checkDogwhistleWithMeta(options)`, `megacallWithMeta(options)` — The same assessments, taking an options object (the plain method's parameters plus `revisionToken`) and returning `{ result, revisionToken }`

**Perspective Compatibility:**
- `client.perspective.analyzeComment(request)` — Public Perspective-compatible analyzeComment wrapper
- `client.perspective.suggestCommentScore(request)` — Public Perspective-compatible suggestCommentScore wrapper

**Authentication:**
- `checkUserCredentials()` — Verify API credentials and subscription status

### Error Handling

```typescript
import {
  RespectifyError,              // Base error
  AuthenticationError,          // Invalid credentials (401)
  BadRequestError,              // Invalid parameters (400)
  ArticleContextNotFoundError,  // Article context cannot be resolved (400); regenerate it
  PaymentRequiredError,         // Subscription or credit required (402)
  FreeAllowanceExhaustedError,  // Free plan used up (402, a PaymentRequiredError); has upgradeUrl
  RevisionLimitReachedError,    // A free-plan comment has used all five attempts (409)
  RateLimitedError,             // Too many requests (429); has retryAfterSeconds
  UnsupportedMediaTypeError,    // Wrong content type (415)
  ServerError,                  // Server issues (500+)
  ResponseParseError,           // Malformed API response
} from "respectify";

try {
  const result = await client.checkSpam("test", articleId);
} catch (error) {
  if (error instanceof AuthenticationError) {
    console.error("Check your API credentials");
  } else if (error instanceof FreeAllowanceExhaustedError) {
    console.error(`Free plan used up; add credit at ${error.upgradeUrl}`);
  } else if (error instanceof PaymentRequiredError) {
    console.error("This feature requires a paid plan");
  } else if (error instanceof RateLimitedError) {
    console.error(`Slow down; retry in ${error.retryAfterSeconds ?? "a few"} seconds`);
  } else if (error instanceof BadRequestError) {
    console.error(`Invalid request: ${error.message}`);
  }
}
```

All errors include `statusCode` and `responseData` properties for debugging, and `errorCode` when the API body carried an `error_code` (`ERROR_CODES` lists the known ones: `free_allowance_exhausted`, `revision_limit_reached`, `free_rate_limited`). On the Perspective-compatible endpoints the code comes from the Google-style `error.details[].reason`, lower-cased.

### Response Sanitization

All string values in API responses are automatically HTML-encoded to prevent XSS. API responses echo back user-submitted comment text (in quoted fallacies, objectionable phrases, etc.) so this encoding is applied by default to make responses safe to render in HTML.

## Development

### Running Tests

Create a repo-level `.env` file with your credentials:

```bash
RESPECTIFY_EMAIL=your-email@example.com
RESPECTIFY_API_KEY=your-api-key
```

```bash
npm install
npm test              # Run all tests (unit + integration)
npm run test:watch    # Watch mode
npm run typecheck     # Type checking only
npm run build         # Build for distribution
```

## Requirements

- Node.js >= 18 (uses native `fetch`)
- One runtime dependency: [`escape-html`](https://www.npmjs.com/package/escape-html) for response sanitization

## License

MIT — see [LICENSE](LICENSE) for details.

## Links

- [Respectify](https://respectify.ai)
- [API Documentation](https://docs.respectify.org)
- [GitHub Issues](https://github.com/respectify/respectify-ts/issues)
